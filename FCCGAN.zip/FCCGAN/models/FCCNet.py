from torch import nn, Tensor
import torch

class Trans_Up(nn.Module):
    def __init__(self, in_planes, out_planes):
        super(Trans_Up, self).__init__()
        layers = [
            nn.ConvTranspose2d(in_planes, out_planes, 4, 2, 1, bias=False),
            nn.InstanceNorm2d(out_planes),
            nn.Hardswish(inplace=True),
        ]
        self.convTrans = nn.Sequential(*layers)

    def forward(self, x):
        out = self.convTrans(x)
        return out


# Multi-scale Dense Block Feature
class MDFA(nn.Module):
    def __init__(self, block_num, inter_channel, channel):
        super(MDFA, self).__init__()
        concat_channels = channel + block_num * inter_channel
        channels_now = channel
        self.group_list = nn.ModuleList([])
        for i in range(block_num):
            group = nn.Sequential(
                nn.Conv2d(in_channels=channels_now, out_channels=inter_channel, kernel_size=3,
                          stride=1, padding=1),
                nn.GELU(),
            )
            self.add_module(name='group_%d' % i, module=group)
            self.group_list.append(group)
            channels_now += inter_channel

        assert channels_now == concat_channels
        self.fusion = nn.Sequential(
            nn.Conv2d(concat_channels, channel, kernel_size=1, stride=1, padding=0),
            nn.GELU(),
        )

        self.conv_3_1 = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=3, stride=1,padding=1,bias=True)
        self.conv_5_1 = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=5, stride=1,padding=2,bias=True)
        self.conv_f = nn.Conv2d(in_channels=channel * 2, out_channels=channel, kernel_size=3, stride=1, padding=1,bias=True)
        self.relu = nn.GELU()

    def forward(self, x):
        x_3_1 = self.relu(self.conv_3_1(x))
        x_5_1 = self.relu(self.conv_5_1(x))
        x_3 = x_3_1 + x
        x_5 = x_5_1 + x
        x_f = torch.cat([x_3, x_5], dim=1)
        x_f = self.relu(self.conv_f(x_f))

        feature_list = [x_f]
        for group in self.group_list:
            inputs = torch.cat(feature_list, dim=1)
            outputs = group(inputs)
            feature_list.append(outputs)
        inputs = torch.cat(feature_list, dim=1)
        fusion_outputs = self.fusion(inputs)
        block_outputs = fusion_outputs + x
        return block_outputs

class Trans_Down(nn.Module):
    def __init__(self, in_planes, out_planes):
        super(Trans_Down, self).__init__()
        self.conv0 = nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=2, padding=1)
        self.IN1 = nn.InstanceNorm2d(out_planes)
        self.relu = nn.GELU()

    def forward(self, x):
        out = self.relu(self.IN1(self.conv0(x)))
        return out

class make_fdense(nn.Module):
    def __init__(self, nChannels, growthRate, kernel_size=1):
        super(make_fdense, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(nChannels, growthRate, kernel_size=kernel_size, padding=(kernel_size - 1) // 2,
                              bias=False),
            nn.InstanceNorm2d(growthRate, affine=True)
        )

        self.leaky=nn.LeakyReLU(0.1,inplace=True)

    def forward(self, x):
        out = self.leaky(self.conv(x))
        out = torch.cat((x, out), 1)
        return out


class DCA(nn.Module):
    def __init__(self, in_channels):
        super(DCA, self).__init__()
        channel = in_channels * 2
        self.maxpool = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=3, padding=1, stride=1, bias=False),
            nn.AdaptiveMaxPool2d((1, 1))
        )
        self.avgpool = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=3, padding=1, stride=1, bias=False),
            nn.AdaptiveAvgPool2d((1, 1))
        )
        self.fusion = nn.Sequential(
            nn.Conv2d(channel * 2, channel, 1, bias=False),
            nn.GELU(),
            nn.Conv2d(channel, channel, 1, bias=False)
        )
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x, y):
        fea = torch.cat([x, y], dim=1)
        fea_max = self.maxpool(fea)
        fea_avg = self.avgpool(fea)
        fusion = torch.cat([fea_max, fea_avg], dim=1)
        fusion = self.fusion(fusion)
        fea_w = self.softmax(fusion)
        x_w, y_w = fea_w.chunk(2, dim=1)
        mag = x * x_w
        pha = y * y_w
        return mag, pha


class FFEM(nn.Module):
    def __init__(self, nChannels):
        super(FFEM, self).__init__()

        self.din = nn.Sequential(
            nn.Conv2d(nChannels, nChannels, kernel_size=1, padding=0, stride=1),
            nn.GELU(),
            nn.Conv2d(nChannels, nChannels, kernel_size=1, padding=0, stride=1)
        )
        self.dout = nn.Sequential(
            nn.Conv2d(nChannels, nChannels, kernel_size=1, padding=0, stride=1),
            nn.GELU(),
            nn.Conv2d(nChannels, nChannels, kernel_size=1, padding=0, stride=1)
        )
        self.dca = DCA(nChannels)

    def forward(self, x):
        _, _, H, W = x.shape
        fft_y = torch.fft.rfft2(x, norm='backward')
        mag = torch.abs(fft_y)
        pha = torch.angle(fft_y)

        mag_x = self.din(mag)
        pha_x = self.dout(pha)

        mag_dca, pha_dca = self.dca(mag_x, pha_x)

        real = mag_x * torch.cos(mag_dca)
        imag = mag_x * torch.sin(pha_dca)
        y_out = torch.complex(real, imag)  # 64
        out_fft = torch.fft.irfft2(y_out, s=(H, W), norm='backward')
        return out_fft + x


class CPAB(nn.Module):
    def __init__(self, channels):
        super(CPAB, self).__init__()
        self.init_ = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, stride=1, bias=False),
            nn.GELU()
        )
        self.ca = nn.Sequential(
            nn.Conv2d(channels, channels, 1, padding=0, stride=1, bias=False),
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Conv2d(channels, channels // 2, 1, bias=False),
            nn.GELU(),
            nn.Conv2d(channels // 2, channels, 1, bias=False),
            nn.Sigmoid()
        )

        self.stage = nn.Sequential(
            nn.Conv2d(channels, channels, 1, padding=0, stride=1, bias=False),
            nn.GELU()
        )

        self.pa = nn.Sequential(
            nn.Conv2d(channels, channels, 1, padding=0, stride=1, bias=False),
            nn.GELU(),
            nn.Conv2d(channels, channels, 1, padding=0, stride=1, bias=False)
        )

    def forward(self, x):
        x_init = self.init_(x)
        c_w = self.ca(x_init)
        x_c = x_init + self.stage(x_init) * c_w
        x_p = x_c * self.pa(x_c)
        return x_p + x


class CPCM(nn.Module):
    def __init__(self, channels):
        super(CPCM, self).__init__()
        self.color_com = nn.Sequential(
            CPAB(channels),
            nn.Conv2d(channels, channels, 3, 1, 1, bias=False),
            CPAB(channels)
        )
        self.adaptive_com = nn.Sequential(
            CPAB(channels),
            nn.Conv2d(channels, channels, 3, 1, 1, bias=False),
            CPAB(channels),
            nn.Conv2d(channels, channels, 3, 1, 1, bias=False),
            CPAB(channels)
        )

    def forward(self, x, y):
        x_com = self.color_com(x)
        adaptive_feature = self.adaptive_com(x_com + y)
        return adaptive_feature


class Encoder_A(nn.Module):
    def __init__(self):
        super(Encoder_A, self).__init__()

        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 16, 3, 1, 1),
            nn.InstanceNorm2d(16, affine=True),
            nn.GELU(),
            nn.Conv2d(16, 16, 3, 1, 1),
            nn.InstanceNorm2d(16, affine=True),
            nn.GELU(),
        )
        self.Dense_Down_1 = MDFA(3, 32, 32)
        self.Dense_Down_2 = MDFA(3, 64, 64)
        self.Dense_Down_3 = MDFA(3, 128, 128)
        self.Dense_Down_4 = MDFA(3, 256, 256)
        # 下采样
        self.trans_down_1 = Trans_Down(16, 32)
        self.trans_down_2 = Trans_Down(32, 64)
        self.trans_down_3 = Trans_Down(64, 128)
        self.trans_down_4 = Trans_Down(128, 256)

    def forward(self, x):
        down_11 = self.conv1(x)              # 16 256 256

        down_1 = self.trans_down_1(down_11)  # 32 128 128
        down_21 = self.Dense_Down_1(down_1)  # 32 128 128

        down_2 = self.trans_down_2(down_21)  # 64 64 64
        down_31 = self.Dense_Down_2(down_2)  # 64 64 64

        down_3 = self.trans_down_3(down_31)  # 128 32 32
        down_41 = self.Dense_Down_3(down_3)  # 128 32 32

        down_4 = self.trans_down_4(down_41)  # 256 16 16
        down_51 = self.Dense_Down_4(down_4)  # 256 16 16

        return [down_51, down_41, down_31, down_21, down_11]

class Encoder_U(nn.Module):
    def __init__(self):
        super(Encoder_U, self).__init__()

        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 16, 3, 1, 1),
            nn.InstanceNorm2d(16, affine=True),
            nn.Hardswish(inplace=True),
            nn.Conv2d(16, 16, 3, 1, 1),
            nn.InstanceNorm2d(16, affine=True),
            nn.Hardswish(inplace=True),
        )
        self.Dense_Down_1 = MDFA(3, 32, 32)
        self.Dense_Down_2 = MDFA(3, 64, 64)
        self.Dense_Down_3 = MDFA(3, 128, 128)
        self.Dense_Down_4 = MDFA(3, 256, 256)
        # 下采样
        self.trans_down_1 = Trans_Down(16, 32)
        self.trans_down_2 = Trans_Down(32, 64)
        self.trans_down_3 = Trans_Down(64, 128)
        self.trans_down_4 = Trans_Down(128, 256)

    def forward(self, x):
        down_11 = self.conv1(x)              # 16 256 256

        down_1 = self.trans_down_1(down_11)  # 32 128 128
        down_21 = self.Dense_Down_1(down_1)  # 32 128 128

        down_2 = self.trans_down_2(down_21)  # 64 64 64
        down_31 = self.Dense_Down_2(down_2)  # 64 64 64

        down_3 = self.trans_down_3(down_31)  # 128 32 32
        down_41 = self.Dense_Down_3(down_3)  # 128 32 32

        down_4 = self.trans_down_4(down_41)  # 256 16 16
        down_51 = self.Dense_Down_4(down_4)  # 256 16 16

        return [down_51, down_41, down_31, down_21, down_11]


class Generator_A(nn.Module):
    def __init__(self):
        super(Generator_A, self).__init__()

        self.ffem_1 = FFEM(16)
        self.ffem_2 = FFEM(32)
        self.ffem_3 = FFEM(64)
        self.ffem_4 = FFEM(128)

        self.cpcm_1 = CPCM(16)
        self.cpcm_2 = CPCM(32)
        self.cpcm_3 = CPCM(64)
        self.cpcm_4 = CPCM(128)

        self.Block = nn.Sequential(
            nn.Conv2d(256, 256, 3, stride=1, padding=1),
            nn.GELU(),
            nn.Conv2d(256, 256, 3, stride=1, padding=1)
        )

        # 上采样
        self.trans_up_4 = Trans_Up(256, 128)
        self.trans_up_3 = Trans_Up(128, 64)
        self.trans_up_2 = Trans_Up(64, 32)
        self.trans_up_1 = Trans_Up(32, 16)
        # 融合
        self.up_4_fusion = nn.Sequential(
            nn.Conv2d(256, 128, 1, 1, 0),
            nn.InstanceNorm2d(128, affine=True),
            nn.GELU(),
        )
        self.up_3_fusion = nn.Sequential(
            nn.Conv2d(128, 64, 1, 1, 0),
            nn.InstanceNorm2d(64, affine=True),
            nn.GELU(),
        )
        self.up_2_fusion = nn.Sequential(
            nn.Conv2d(64, 32, 1, 1, 0),
            nn.InstanceNorm2d(32, affine=True),
            nn.GELU(),
        )
        self.up_1_fusion = nn.Sequential(
            nn.Conv2d(32, 16, 1, 1, 0),
            nn.InstanceNorm2d(16, affine=True),
            nn.GELU(),
        )
        self.fusion = nn.Sequential(
            nn.Conv2d(16, 16, 1, 1, 0),
            nn.InstanceNorm2d(16, affine=True),
            nn.GELU(),
            nn.Conv2d(16, 16, 3, 1, 1),
            nn.InstanceNorm2d(16, affine=True),
            nn.GELU(),
        )
        self.fusion2 = nn.Sequential(
            nn.Conv2d(16, 3, 3, 1, 1),
            nn.Tanh(),
        )

    def forward(self, x, y):

        [down_51, down_41, down_31, down_21, down_11] = x
        [down_5, down_4, down_3, down_2, down_1] = y

        up_5 = self.Block(down_51) # 256,16,16

        up_4 = self.trans_up_4(up_5)        # 128,32,32
        Fa_4 = self.ffem_4(down_41)
        Fa_fusion_4 = self.up_4_fusion(torch.cat([up_4, Fa_4],dim=1))
        up_fusion_4 = self.cpcm_4(down_4, Fa_fusion_4)

        up_3 = self.trans_up_3(up_fusion_4)  # 64 64 64
        Fa_3 = self.ffem_3(down_31)
        Fa_fusion_3 = self.up_3_fusion(torch.cat([up_3, Fa_3], dim=1))
        up_fusion_3 = self.cpcm_3(down_3, Fa_fusion_3)

        up_2 = self.trans_up_2(up_fusion_3)  # 32 128 128
        Fa_2 = self.ffem_2(down_21)
        Fa_fusion_2 = self.up_2_fusion(torch.cat([up_2, Fa_2], dim=1))
        up_fusion_2 = self.cpcm_2(down_2, Fa_fusion_2)

        up_1 = self.trans_up_1(up_fusion_2)  # 16 256 256
        Fa_1 = self.ffem_1(down_11)
        Fa_fusion_1 = self.up_1_fusion(torch.cat([up_1, Fa_1], dim=1))
        up_fusion_1 = self.cpcm_1(down_1, Fa_fusion_1)

        feature = self.fusion(up_fusion_1)  # 1, 16, 256, 256

        outputs = self.fusion2(feature)
        return outputs


class FCCGAN(nn.Module):
    def __init__(self):
        super(FCCGAN, self).__init__()
        self.EA = Encoder_A()
        self.EU = Encoder_U()
        self.GA = Generator_A()

    def forward(self, x):
        E_x = self.EA(x)
        y = 1 - x
        E_u = self.EU(y)
        outp = self.GA(E_x, E_u)
        return outp
